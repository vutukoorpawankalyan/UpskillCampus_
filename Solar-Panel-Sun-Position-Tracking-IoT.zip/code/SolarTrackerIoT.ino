#include <WiFi.h>
#include <HTTPClient.h>
#include <ESP32Servo.h>

const char* ssid="YOUR_WIFI";
const char* password="YOUR_PASSWORD";
String apiKey="YOUR_THINGSPEAK_API_KEY";

Servo servo;
const int ldrL=34, ldrR=35;
int angle=90;

void setup(){
 Serial.begin(115200);
 servo.attach(18);
 WiFi.begin(ssid,password);
 while(WiFi.status()!=WL_CONNECTED){delay(500);}
}
void loop(){
 int left=analogRead(ldrL), right=analogRead(ldrR);
 if(left-right>50 && angle<180) angle++;
 else if(right-left>50 && angle>0) angle--;
 servo.write(angle);

 if(WiFi.status()==WL_CONNECTED){
  HTTPClient http;
  String url="http://api.thingspeak.com/update?api_key="+apiKey+
             "&field1="+String(left)+"&field2="+String(right)+"&field3="+String(angle);
  http.begin(url); http.GET(); http.end();
 }
 delay(2000);
}
