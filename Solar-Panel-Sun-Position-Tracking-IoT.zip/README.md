# Solar Panel Sun Position Tracking with IoT

ESP32-based solar tracker using two LDRs and a servo. Publishes LDR values and servo angle to ThingSpeak.

## Hardware
- ESP32
- 2x LDR
- Servo SG90
- Resistors
