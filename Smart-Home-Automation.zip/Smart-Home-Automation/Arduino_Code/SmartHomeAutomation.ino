#define BLYNK_PRINT Serial
#include <ESP8266WiFi.h>
void setup(){Serial.begin(9600);}
void loop(){// Add relay, DHT11, PIR and LDR logic here
}