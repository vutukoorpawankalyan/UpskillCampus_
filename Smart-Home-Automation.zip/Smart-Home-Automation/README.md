# Smart Home Automation IoT
ESP8266-based smart home automation project.

## Features
- WiFi based control
- Relay switching
- DHT11 monitoring
- PIR motion detection
- LDR automatic lighting

## Hardware
NodeMCU ESP8266, Relay, DHT11, PIR, LDR.
